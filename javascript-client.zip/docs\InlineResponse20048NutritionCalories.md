# SpoonacularApi.InlineResponse20048NutritionCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Number** |  | 
**unit** | **String** |  | 
**confidenceRange95Percent** | [**InlineResponse20048NutritionCaloriesConfidenceRange95Percent**](InlineResponse20048NutritionCaloriesConfidenceRange95Percent.md) |  | 
**standardDeviation** | **Number** |  | 


