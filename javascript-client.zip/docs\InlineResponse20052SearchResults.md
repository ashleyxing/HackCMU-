# SpoonacularApi.InlineResponse20052SearchResults

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**totalResults** | **Number** |  | 
**results** | [**[InlineResponse20052Results]**](InlineResponse20052Results.md) |  | [optional] 


