# SpoonacularApi.InlineResponse20024

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**image** | **String** |  | 
**id** | **Number** |  | 
**aisle** | **String** |  | 
**possibleUnits** | **[String]** |  | 


