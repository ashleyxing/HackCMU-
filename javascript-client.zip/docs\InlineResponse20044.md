# SpoonacularApi.InlineResponse20044

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **[String]** |  | 
**pairingText** | **String** |  | 
**productMatches** | [**[InlineResponse20044ProductMatches]**](InlineResponse20044ProductMatches.md) |  | 


