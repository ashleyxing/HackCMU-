# SpoonacularApi.InlineResponse20025

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[InlineResponse20025Results]**](InlineResponse20025Results.md) |  | 
**offset** | **Number** |  | 
**_number** | **Number** |  | 
**totalResults** | **Number** |  | 


