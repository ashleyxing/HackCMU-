# SpoonacularApi.InlineResponse20050

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotations** | **[Object]** |  | 


