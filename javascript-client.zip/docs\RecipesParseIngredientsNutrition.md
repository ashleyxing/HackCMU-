# SpoonacularApi.RecipesParseIngredientsNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**[RecipesParseIngredientsNutritionNutrients]**](RecipesParseIngredientsNutritionNutrients.md) |  | 
**properties** | [**[RecipesParseIngredientsNutritionProperties]**](RecipesParseIngredientsNutritionProperties.md) |  | 
**flavonoids** | [**[RecipesParseIngredientsNutritionProperties]**](RecipesParseIngredientsNutritionProperties.md) |  | 
**caloricBreakdown** | [**RecipesParseIngredientsNutritionCaloricBreakdown**](RecipesParseIngredientsNutritionCaloricBreakdown.md) |  | 
**weightPerServing** | [**RecipesParseIngredientsNutritionWeightPerServing**](RecipesParseIngredientsNutritionWeightPerServing.md) |  | 


