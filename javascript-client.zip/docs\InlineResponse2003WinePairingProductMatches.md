# SpoonacularApi.InlineResponse2003WinePairingProductMatches

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**description** | **String** |  | 
**price** | **String** |  | 
**imageUrl** | **String** |  | 
**averageRating** | **Number** |  | 
**ratingCount** | **Number** |  | 
**score** | **Number** |  | 
**link** | **String** |  | 


