# SpoonacularApi.RecipesParseIngredientsNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentProtein** | **Number** |  | 
**percentFat** | **Number** |  | 
**percentCarbs** | **Number** |  | 


