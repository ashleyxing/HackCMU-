# SpoonacularApi.InlineResponse20040Days

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutritionSummary** | [**InlineResponse20038NutritionSummary**](InlineResponse20038NutritionSummary.md) |  | [optional] 
**nutritionSummaryBreakfast** | [**InlineResponse20038NutritionSummary**](InlineResponse20038NutritionSummary.md) |  | [optional] 
**nutritionSummaryLunch** | [**InlineResponse20038NutritionSummary**](InlineResponse20038NutritionSummary.md) |  | [optional] 
**nutritionSummaryDinner** | [**InlineResponse20038NutritionSummary**](InlineResponse20038NutritionSummary.md) |  | [optional] 
**day** | **String** |  | 
**items** | [**[InlineResponse20040Items]**](InlineResponse20040Items.md) |  | [optional] 


