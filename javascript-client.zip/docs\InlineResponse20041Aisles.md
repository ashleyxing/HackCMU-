# SpoonacularApi.InlineResponse20041Aisles

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**items** | [**[InlineResponse20041Items]**](InlineResponse20041Items.md) |  | [optional] 


