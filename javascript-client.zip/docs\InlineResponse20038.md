# SpoonacularApi.InlineResponse20038

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**days** | [**[InlineResponse20038Days]**](InlineResponse20038Days.md) |  | 


