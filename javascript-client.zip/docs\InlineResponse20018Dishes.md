# SpoonacularApi.InlineResponse20018Dishes

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | 
**name** | **String** |  | 


