# SpoonacularApi.InlineResponse20045

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**wineDescription** | **String** |  | 


