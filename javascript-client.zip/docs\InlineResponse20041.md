# SpoonacularApi.InlineResponse20041

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**[InlineResponse20041Aisles]**](InlineResponse20041Aisles.md) |  | 
**cost** | **Number** |  | 
**startDate** | **Number** |  | 
**endDate** | **Number** |  | 


