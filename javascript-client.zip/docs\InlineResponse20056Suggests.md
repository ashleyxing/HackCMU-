# SpoonacularApi.InlineResponse20056Suggests

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**u** | **[Object]** |  | 


