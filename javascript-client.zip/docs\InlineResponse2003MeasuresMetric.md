# SpoonacularApi.InlineResponse2003MeasuresMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | 
**unitLong** | **String** |  | 
**unitShort** | **String** |  | 


