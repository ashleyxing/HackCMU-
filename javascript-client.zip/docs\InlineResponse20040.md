# SpoonacularApi.InlineResponse20040

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | 
**days** | [**[InlineResponse20040Days]**](InlineResponse20040Days.md) |  | 


