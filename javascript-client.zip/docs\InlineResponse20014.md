# SpoonacularApi.InlineResponse20014

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**summary** | **String** |  | 
**title** | **String** |  | 


