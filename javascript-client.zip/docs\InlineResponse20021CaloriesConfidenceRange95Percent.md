# SpoonacularApi.InlineResponse20021CaloriesConfidenceRange95Percent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | **Number** |  | 
**min** | **Number** |  | 


