# SpoonacularApi.InlineResponse20011

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**[InlineResponse20011Ingredients]**](InlineResponse20011Ingredients.md) |  | 


