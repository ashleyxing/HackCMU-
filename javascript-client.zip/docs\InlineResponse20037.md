# SpoonacularApi.InlineResponse20037

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meals** | [**[InlineResponse2005]**](InlineResponse2005.md) |  | 
**nutrients** | [**InlineResponse20037Nutrients**](InlineResponse20037Nutrients.md) |  | 


