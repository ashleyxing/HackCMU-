# SpoonacularApi.InlineResponse20056

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggests** | [**InlineResponse20056Suggests**](InlineResponse20056Suggests.md) |  | 
**words** | **[Object]** |  | 


