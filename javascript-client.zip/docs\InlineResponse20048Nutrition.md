# SpoonacularApi.InlineResponse20048Nutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipesUsed** | **Number** |  | 
**calories** | [**InlineResponse20048NutritionCalories**](InlineResponse20048NutritionCalories.md) |  | 
**fat** | [**InlineResponse20048NutritionCalories**](InlineResponse20048NutritionCalories.md) |  | 
**protein** | [**InlineResponse20048NutritionCalories**](InlineResponse20048NutritionCalories.md) |  | 
**carbs** | [**InlineResponse20048NutritionCalories**](InlineResponse20048NutritionCalories.md) |  | 


