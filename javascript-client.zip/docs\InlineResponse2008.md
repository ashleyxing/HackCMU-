# SpoonacularApi.InlineResponse2008

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | **Number** |  | 
**saltiness** | **Number** |  | 
**sourness** | **Number** |  | 
**bitterness** | **Number** |  | 
**savoriness** | **Number** |  | 
**fattiness** | **Number** |  | 
**spiciness** | **Number** |  | 


