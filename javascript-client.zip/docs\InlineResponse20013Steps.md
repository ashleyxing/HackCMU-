# SpoonacularApi.InlineResponse20013Steps

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_number** | **Number** |  | 
**step** | **String** |  | 
**ingredients** | [**[InlineResponse20013Ingredients]**](InlineResponse20013Ingredients.md) |  | [optional] 
**equipment** | [**[InlineResponse20013Ingredients]**](InlineResponse20013Ingredients.md) |  | [optional] 


