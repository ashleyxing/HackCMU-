# SpoonacularApi.InlineResponse20021Calories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confidenceRange95Percent** | [**InlineResponse20021CaloriesConfidenceRange95Percent**](InlineResponse20021CaloriesConfidenceRange95Percent.md) |  | 
**standardDeviation** | **Number** |  | 
**unit** | **String** |  | 
**value** | **Number** |  | 


