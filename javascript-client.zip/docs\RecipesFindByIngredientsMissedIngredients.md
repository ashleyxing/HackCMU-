# SpoonacularApi.RecipesFindByIngredientsMissedIngredients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | **Number** |  | 
**id** | **Number** |  | 
**image** | **String** |  | 
**meta** | **[String]** |  | [optional] 
**name** | **String** |  | 
**original** | **String** |  | 
**originalName** | **String** |  | 
**unit** | **String** |  | 
**unitLong** | **String** |  | 
**unitShort** | **String** |  | 


