# SpoonacularApi.InlineResponse20023

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalGlycemicLoad** | **Number** |  | 
**ingredients** | [**[InlineResponse20023Ingredients]**](InlineResponse20023Ingredients.md) |  | 


