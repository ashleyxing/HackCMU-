# SpoonacularApi.InlineResponse20041Measures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | [**RecipesParseIngredientsNutritionWeightPerServing**](RecipesParseIngredientsNutritionWeightPerServing.md) |  | 
**metric** | [**RecipesParseIngredientsNutritionWeightPerServing**](RecipesParseIngredientsNutritionWeightPerServing.md) |  | 
**us** | [**RecipesParseIngredientsNutritionWeightPerServing**](RecipesParseIngredientsNutritionWeightPerServing.md) |  | 


