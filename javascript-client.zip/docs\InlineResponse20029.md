# SpoonacularApi.InlineResponse20029

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customFoods** | [**[InlineResponse20029CustomFoods]**](InlineResponse20029CustomFoods.md) |  | 
**type** | **String** |  | 
**offset** | **Number** |  | 
**_number** | **Number** |  | 


