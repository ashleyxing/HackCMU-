# SpoonacularApi.InlineResponse20010Ingredients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**InlineResponse20010Amount**](InlineResponse20010Amount.md) |  | [optional] 
**image** | **String** |  | 
**name** | **String** |  | 
**price** | **Number** |  | 


