# SpoonacularApi.InlineResponse20016

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsedInstructions** | **[Object]** |  | 
**ingredients** | **[Object]** |  | 
**equipment** | **[Object]** |  | 


