# SpoonacularApi.InlineResponse20046

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommendedWines** | [**[InlineResponse20046RecommendedWines]**](InlineResponse20046RecommendedWines.md) |  | 
**totalFound** | **Number** |  | 


