# SpoonacularApi.InlineResponse20023Ingredients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**original** | **String** |  | 
**glycemicIndex** | **Number** |  | 
**glycemicLoad** | **Number** |  | 


