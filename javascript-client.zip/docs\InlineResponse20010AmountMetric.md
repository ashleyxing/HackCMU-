# SpoonacularApi.InlineResponse20010AmountMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit** | **String** |  | 
**value** | **Number** |  | 


