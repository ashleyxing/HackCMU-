# SpoonacularApi.InlineResponse200Results

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**calories** | **Number** |  | 
**carbs** | **String** |  | 
**fat** | **String** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 
**protein** | **String** |  | 


