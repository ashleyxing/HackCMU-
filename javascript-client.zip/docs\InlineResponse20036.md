# SpoonacularApi.InlineResponse20036

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**restaurantChain** | **String** |  | 
**nutrition** | [**InlineResponse20028Nutrition**](InlineResponse20028Nutrition.md) |  | 
**badges** | **[String]** |  | 
**breadcrumbs** | **[String]** |  | 
**generatedText** | **String** |  | [optional] 
**imageType** | **String** |  | 
**likes** | **Number** |  | 
**servings** | [**InlineResponse20028Servings**](InlineResponse20028Servings.md) |  | 
**price** | **Number** |  | [optional] 
**spoonacularScore** | **Number** |  | [optional] 


