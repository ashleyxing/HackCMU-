# SpoonacularApi.InlineResponse20048

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition** | [**InlineResponse20048Nutrition**](InlineResponse20048Nutrition.md) |  | 
**category** | [**InlineResponse20048Category**](InlineResponse20048Category.md) |  | 
**recipes** | [**[InlineResponse20048Recipes]**](InlineResponse20048Recipes.md) |  | 


