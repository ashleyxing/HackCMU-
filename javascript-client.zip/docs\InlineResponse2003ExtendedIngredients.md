# SpoonacularApi.InlineResponse2003ExtendedIngredients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | **Number** |  | 
**consitency** | **String** |  | 
**id** | **Number** |  | 
**image** | **String** |  | 
**measures** | [**InlineResponse2003Measures**](InlineResponse2003Measures.md) |  | [optional] 
**meta** | **[String]** |  | [optional] 
**name** | **String** |  | 
**original** | **String** |  | 
**originalName** | **String** |  | 
**unit** | **String** |  | 


