# SpoonacularApi.InlineResponse200

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | 
**_number** | **Number** |  | 
**results** | [**[InlineResponse200Results]**](InlineResponse200Results.md) |  | 
**totalResults** | **Number** |  | 


