# SpoonacularApi.InlineResponse20044ProductMatches

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**averageRating** | **Number** |  | 
**description** | **Object** |  | [optional] 
**imageUrl** | **String** |  | 
**link** | **String** |  | 
**price** | **String** |  | 
**ratingCount** | **Number** |  | 
**score** | **Number** |  | 


