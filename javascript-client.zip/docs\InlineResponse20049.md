# SpoonacularApi.InlineResponse20049

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answer** | **String** |  | 
**image** | **String** |  | 


