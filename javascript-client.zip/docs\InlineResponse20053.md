# SpoonacularApi.InlineResponse20053

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**videos** | [**[InlineResponse20053Videos]**](InlineResponse20053Videos.md) |  | 
**totalResults** | **Number** |  | 


