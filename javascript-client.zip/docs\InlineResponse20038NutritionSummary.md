# SpoonacularApi.InlineResponse20038NutritionSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**[InlineResponse20038NutritionSummaryNutrients]**](InlineResponse20038NutritionSummaryNutrients.md) |  | 


