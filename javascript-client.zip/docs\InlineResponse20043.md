# SpoonacularApi.InlineResponse20043

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairings** | **[String]** |  | 
**text** | **String** |  | 


