# SpoonacularApi.InlineResponse20052

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **String** |  | 
**totalResults** | **Number** |  | 
**limit** | **Number** |  | 
**offset** | **Number** |  | 
**searchResults** | [**[InlineResponse20052SearchResults]**](InlineResponse20052SearchResults.md) |  | 


