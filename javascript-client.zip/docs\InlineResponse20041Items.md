# SpoonacularApi.InlineResponse20041Items

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | 
**measures** | [**InlineResponse20041Measures**](InlineResponse20041Measures.md) |  | [optional] 
**pantryItem** | **Boolean** |  | 
**aisle** | **String** |  | 
**cost** | **Number** |  | 
**ingredientId** | **Number** |  | 


