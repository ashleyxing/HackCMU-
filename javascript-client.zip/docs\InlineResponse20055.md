# SpoonacularApi.InlineResponse20055

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answerText** | **String** |  | 
**media** | **[Object]** |  | 


