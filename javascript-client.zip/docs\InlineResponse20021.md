# SpoonacularApi.InlineResponse20021

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**InlineResponse20021Calories**](InlineResponse20021Calories.md) |  | 
**carbs** | [**InlineResponse20021Calories**](InlineResponse20021Calories.md) |  | 
**fat** | [**InlineResponse20021Calories**](InlineResponse20021Calories.md) |  | 
**protein** | [**InlineResponse20021Calories**](InlineResponse20021Calories.md) |  | 
**recipesUsed** | **Number** |  | 


